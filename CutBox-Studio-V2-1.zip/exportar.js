function mostrarSVG(svg,nombreArchivo){
  document.getElementById("resultado").innerHTML =
    svg +
    `<br><a class="descarga" download="${nombreArchivo}.svg" href="data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}">📥 Descargar SVG</a>`+
    `<div class="info">Archivo: ${nombreArchivo}.svg · Tamaño A4 · SVG vectorial</div>`;
}